#pragma strict



function Start () {

}

function Update () 
{
	transform.Rotate(0,1,0);
	
}
